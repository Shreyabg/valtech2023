package com.valtech.assignment.Jdbc.components;

public interface CompanyDAO {
	public long count() ;
	void createCompany(Company comp);
	void deleteCompany(int id);
}
