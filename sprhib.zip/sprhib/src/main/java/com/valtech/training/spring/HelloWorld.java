package com.valtech.training.spring;

public class HelloWorld {
	
	public String hello(String name) {
	return "Hello" +name;
	

	}
	

}
