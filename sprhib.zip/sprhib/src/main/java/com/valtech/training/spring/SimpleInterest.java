package com.valtech.training.spring;

public interface SimpleInterest {
	double computInterest(int prin,int roi,int duration);
	

}
