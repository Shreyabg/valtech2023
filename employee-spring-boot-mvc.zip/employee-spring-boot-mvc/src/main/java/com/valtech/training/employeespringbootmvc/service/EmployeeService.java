package com.valtech.training.employeespringbootmvc.service;

import java.util.List;

import com.valtech.training.employeespringbootmvc.entities.Employee;



public interface EmployeeService {
	Employee createOrder(Employee emp);

	Employee updateOrder(Employee emp);

	Employee getOrder(int empId);

	List<Employee> getAllEmployees();

}
