package com.valtech.training.employeespringbootmvc.service;

import java.time.LocalDate;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.valtech.training.employeespringbootmvc.entities.Employee;
import com.valtech.training.employeespringbootmvc.repositories.EmployeeRepo;

@Service
@Transactional(propagation = Propagation.REQUIRED)
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeRepo empRepo;
	
	@PostConstruct
	public void populateOrders() {
		empRepo.save(new Employee(1,"John",32,2,1,30000));
		empRepo.save(new Employee(2,"Alexa",23,1,1,20000));
		empRepo.save(new Employee(3,"Michel",25,2,2,50000));
		
	}
	
	
	@Override
	public Employee createOrder(Employee emp) {
		// TODO Auto-generated method stub
		System.out.println(empRepo.getClass().getName());
		return empRepo.save(emp);
	}

	@Override
	public Employee updateOrder(Employee emp) {
		// TODO Auto-generated method stub
		return empRepo.save(emp);
	}

	@Override
	public Employee getOrder(int empId) {
		// TODO Auto-generated method stub
		return empRepo.getReferenceById(empId);
	}

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return empRepo.findAll();
	}

}
